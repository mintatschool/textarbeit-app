import React from 'react';

export default function Test() {
    return (
        <div style={{ padding: 50, fontSize: 30, color: 'green' }}>
            <h1>System Check</h1>
            <p>React is running correctly!</p>
        </div>
    );
}
